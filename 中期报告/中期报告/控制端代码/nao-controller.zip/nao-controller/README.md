# nao-controller
A program running on nao robot, receiving commands in string through socket and executing them.
